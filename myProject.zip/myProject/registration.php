<?php
session_start();
//header('location:main.php');
$con=mysqli_connect('localhost','root','');
mysqli_select_db($con,'myproject');
$name = $_POST['user'];
$pass = $_POST['pass'];
$phone=$_POST['number'];
$email = $_POST['email'];
$code = $_POST['code'];
$religion = $_POST['religion'];
$gender = $_POST['gender'];


$s = " select * from user where name='$name'";

$result = mysqli_query($con, $s); 

$num = mysqli_num_rows($result);

if($num == 1){
	echo "username already taken";
}
else{
	$reg = " insert into user (name, email,phone,pass,code, religion, gender) values('$name', '$email', '$phone' , '$pass', '$code' ,'$religion', '$gender')";

	mysqli_query($con, $reg);
	echo "Registration Successful";
	$_SESSION['msg'] = '<div class="message">Registration Successful</div>';
	header('location: main.php');
}


?>