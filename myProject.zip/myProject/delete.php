<?php
	session_start(); 
	if(!isset($_SESSION['username'])) {
			header('Location: main.php');
}
?>

<?php
	$id = $_GET['id'];
	$con=mysqli_connect('localhost','root','');
	mysqli_select_db($con,'myproject');
	$s = "DELETE FROM user WHERE id=$id";
	$result = mysqli_query($con, $s); 
	header("Location:seeuser.php");
?>

