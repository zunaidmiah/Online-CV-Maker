<!DOCTYPE html>
<html>
<head>
	<title>user list</title>
</head>

<body>
	<table width='80%' border=0>
		<tr bgcolor='#CCCCCC'>
			<td>ID</td>
			<td>Name</td>
			<td>Email</td>
			<td>Phone</td>
			<td>password</td>
			<td>Code</td>
			<td>Religion</td>
			<td>Gender</td>
		</tr>
		<?php
		session_start();
		 if(!isset($_SESSION['username'])){
		header('location:main.php');
		 }
		$con=mysqli_connect('localhost','root','');
		mysqli_select_db($con,'myproject');
		$s = " select * from user";
		$result = mysqli_query($con, $s); 
		while($res = mysqli_fetch_array($result)) {		
			echo "<tr>";
			echo "<td>".$res['id']."</td>";
			echo "<td>".$res['name']."</td>";
			echo "<td>".$res['email']."</td>";
			echo "<td>".$res['phone']."</td>";	
			echo "<td>".$res['pass']."</td>";	
			echo "<td>".$res['code']."</td>";	
			echo "<td>".$res['religion']."</td>";	
			echo "<td>".$res['gender']."</td>";	
			echo "<td><a href=\"update.php?id=$res[id]\">Update</a> | <a href=\"delete.php?id=$res[id]\" onClick=\"return confirm('Are you sure you want to delete?')\">Delete</a></td>";		
		}
		?>
	</table>	
</body>
</html>