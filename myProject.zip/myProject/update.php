<?php
	session_start(); 
	if(!isset($_SESSION['username'])) {
			header('Location: main.php');
}
?>

<?php
	$id = $_GET['id'];
	$con=mysqli_connect('localhost','root','');
	mysqli_select_db($con,'myproject');
	$s = "SELECT * FROM user WHERE id=$id";
	$result = mysqli_query($con, $s); 
	while($res = mysqli_fetch_array($result))
	{
		$id = $res['id'];
		$name = $res['name'];
		$email = $res['email'];
		$phone = $res['phone'];
		$pass = $res['pass'];
		$code = $res['code'];
		$religion = $res['religion'];
		$gender = $res['gender'];
	}
?>

<html>
<head>	
	<title>Update Data</title>
</head>

<body>
	<form name="form1" method="post" action="seeuser.php">
		<table border="0">
			<tr> 
				<td>ID</td>
				<td><input type="text" name="id" value="<?php echo $id;?>"></td>
			</tr>
			<tr> 
				<td>Name</td>
				<td><input type="text" name="name" value="<?php echo $name;?>"></td>
			</tr>
			<tr> 
				<td>Email</td>
				<td><input type="email" name="email" value="<?php echo $email;?>"></td>
			</tr>
			<tr> 
				<td>Phone</td>
				<td><input type="number" name="number" value="<?php echo $phone;?>"></td>
			</tr>
			<tr> 
				<td>Password</td>
				<td><input type="password" name="pass" value="<?php echo $pass;?>"></td>
			</tr>
			<tr> 
				<td>Code</td>
				<td><input type="text" name="code" value="<?php echo $code;?>"></td>
			</tr>
			<tr> 
				<td>Religion</td>
				<td><input type="text" name="religion" value="<?php echo $religion;?>"></td>
			</tr>
			<tr> 
				<td>Gender</td>
				<td><input type="text" name="gender" value="<?php echo $gender;?>"></td>
			</tr>
			<tr>
				<td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
				<td><input type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
</body>
</html>