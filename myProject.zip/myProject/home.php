<?php 
  session_start();
  if(!isset($_SESSION['username'])){
    header('location:main.php');
  }
 ?>
 
<!doctype html>
<html>
	<head>
		<title>Homepage</title>
		<link rel="stylesheet" type="text/css" href="stylesheet.css">
		<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	</head>
	<body>
		
		<div class="col-md-6">
			<h1>Homepage</h1> 
			<h4><b>Welcome to Our Website</b></h4><br>
			
		</div>
		<div class="col-md-6">
			
			<form action="cv.php" method="post">
				
				<button type="submit" class="btn btn-primary"> Create CV </button><br><br>

			</form>
		</div>
		
		</div>
		<div class="col-md-6">
			
			<form action="mycv.php" method="post">
				
				<button type="submit" class="btn btn-primary"> See My CV</button><br><br>

			</form>
		</div>
		
		<div class="col-md-6">
			
			<form action="user.php" method="post">
				
				<button type="submit" class="btn btn-primary"> add user </button><br><br>

			</form>
		</div>
		
		<div class="col-md-6">
			
			<form action="seeuser.php" method="post">
				
				<button type="submit" class="btn btn-primary"> See user list </button><br><br>

			</form>
		</div>
		
		<div class="col-md-6">
		<form action="logout.php" method="post">
				
				<button type="submit" class="btn btn-primary"> Logout </button><br><br>

			</form>
		</div>
	</body>
</html>