<?php 
  session_start();
  if(!isset($_SESSION['username'])){
    header('location:main.php');
  }
 ?>
<!doctype html>
<html>
<head>
<title>Add user Info</title>
<link rel="stylesheet" type="text/css" href="stylesheet.css">
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

</head>		
		<body>
		<div class="col-md-6">
			<h2>Add user</h2> <br>
			<form action="adduser.php" method="post">
				<div class="form-group">

					<label><b>Full Name</b></label>
					<input type="text" name="user" class="form-control" placeholder="Enter Fullname" required>
				</div>
                <div class="form-group">

					<label><b>Email</b></label>
					<input type="email" name="email" class="form-control" placeholder="Enter Email" required>
				</div>
				
				<div class="form-group">

					<label><b>Phone Number</b></label>
					<input type="number_format" name="number" class="form-control" placeholder="Enter Phone Number" required>
				</div>

				<button type="submit" class="btn btn-primary"> Add </button><br><br>

			</form>
		</div>
		<div class="col-md-6">
			
			<form action="seeuser.php" method="post">
				
				<button type="submit" class="btn btn-primary"> see user list </button><br><br>

			</form>
		</div>
		</body>
		</html>