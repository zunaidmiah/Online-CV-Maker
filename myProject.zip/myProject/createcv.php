<?php 
  session_start();
  if(!isset($_SESSION['username'])){
    header('location:main.php');
  }
 ?>
<?php
$name=$_POST['name'];
$email=$_POST['email'];
$number=$_POST['number'];
$address=$_POST['address'];
$scl=$_POST['school'];
$varsity=$_POST['varsity'];
$skills=$_POST['skills'];
$religion=$_POST['religion'];
$gender=$_POST['gender'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>CV Maker</title>
	<link rel="stylesheet" href="css is here.css"/>
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Roboto'>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style>
		html,body,h1,h2,h3,h4,h5,h6 {font-family: "Roboto", sans-serif}
	</style>
</head>
<body>
	<form action="home.php" method="post">
		<div class="main">
		<div class="left">
		<div class="w3-display-container">
          <img src="DSC_1112.JPG" width="300" height="400" alt="CVpic">
          <div class="w3-display-bottomleft w3-container w3-text-black">
          </div>
        </div>
		 <div class="w3-container">
          <p><i class="fa fa-briefcase fa-fw w3-margin-right w3-large w3-text-teal"></i><?php echo $name;?></p>
          <p><i class="fa fa-briefcase fa-fw w3-margin-right w3-large w3-text-teal"></i><?php echo $skills;?></p>
          <p><i class="fa fa-home fa-fw w3-margin-right w3-large w3-text-teal"></i><?php echo $address;?></p>
          <p><i class="fa fa-envelope fa-fw w3-margin-right w3-large w3-text-teal"></i><?php echo $email;?></p>
          <p><i class="fa fa-phone fa-fw w3-margin-right w3-large w3-text-teal"></i><?php echo $number;?></p>
          <hr>
		  </div>
		  </div>
		  
		  <div class="right">
		  <div class="w3-container w3-card w3-white">
        <h2 class="w3-text-grey w3-padding-16"><i class="fa fa-certificate fa-fw w3-margin-right w3-xxlarge w3-text-teal"></i>Education</h2>
        <div class="w3-container">
		<h6 class="w3-text-teal"><i class="fa fa-calendar fa-fw w3-margin-right"></i>School Name</h6>
          <h5 class="w3-opacity"><b><?php echo $scl;?></b></h5>
          <hr>
        </div>
        <div class="w3-container">
          <h6 class="w3-text-teal"><i class="fa fa-calendar fa-fw w3-margin-right"></i>University Name</h6>	  
          <h5 class="w3-opacity"><b><?php echo $varsity;?></b></h5>
          <p>Bachelor Degree</p><br>
        </div>
      </div>
	  <div class="w3-container w3-card w3-white">
        <h2 class="w3-text-grey w3-padding-16"><i class="fa fa-certificate fa-fw w3-margin-right w3-xxlarge w3-text-teal"></i>Information</h2>
        <div class="w3-container">
		<h6 class="w3-text-teal"><i class="fa fa-calendar fa-fw w3-margin-right"></i>Religion</h6>
          <h5 class="w3-opacity"><b><?php echo $religion;?></b></h5>
          <hr>
        </div>
        <div class="w3-container">
          <h6 class="w3-text-teal"><i class="fa fa-calendar fa-fw w3-margin-right"></i>Gender</h6>	  
          <h5 class="w3-opacity"><b><?php echo $gender;?></b></h5>
        </div>
      </div>
		  </div>
		  </div>
		  <button type="submit" class="btn btn-primary"> DONE </button>

	</form>
</body>
</html>