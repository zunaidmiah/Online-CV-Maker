<?php 
  session_start();
  if(!isset($_SESSION['username'])){
    header('location:main.php');
  }
 ?>
<!doctype html>
<html>
	<head>
		<title>CV Maker</title>
		
		<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	</head>
	<body style="background-color:Tomato;">
		
		<div class="col-md-6"> 
			<h4><b>Your Cv making Completed....</b></h4><br>
			<form action="logout.php" method="post">
				
				<button type="submit" class="btn btn-primary"> Logout </button><br><br>

			</form>
		</div>
		
		<div class="col-md-6"> 
			<form action="home.php" method="post">
				
				<button type="submit" class="btn btn-primary"> Homepage </button><br><br>

			</form>
		</div>
		
		
	</body>
</html>