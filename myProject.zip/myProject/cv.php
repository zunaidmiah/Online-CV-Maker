<?php 
  session_start();
  if(!isset($_SESSION['username'])){
    header('location:main.php');
  }
 ?>
 
<!DOCTYPE html>
<html>
	<head>
		<title>CV Maker</title>
		<script type="text/javascript" src="photo.js"></script>
		<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
	</head>
	<body style="background-color:SlateBlue;">
		<div class="col-md-6">
			<h2>Online CV Maker</h2> <br>
			<form action="createcv.php" method="POST">
			
				<div class="form-group">
					<label><b>Your Photo upload here</b></label><br>
					<input type='file' id="imgInp" />
					
				</div>
				
	
				<div class="form-group">

					<label><b>Full Name</b></label>
					<input type="text" name="name" class="form-control" placeholder="Enter Fullname" required>
				</div>
                <div class="form-group">

					<label><b>Email</b></label>
					<input type="email" name="email" class="form-control" placeholder="Enter Email" required>
				</div>
				
				<div class="form-group">

					<label><b>Phone Number</b></label>
					<input type="number_format" name="number" class="form-control" placeholder="Enter Phone Number" required>
				</div>
				
				<div class="form-group">
					<label><b>Present Address</b></label> <br>
					<input type="text" name="address" class="form-control" placeholder="Present Address" required>
				</div>

				<div class="form-group">

					<label><b>School Name</b></label>
					<input type="text" name="school" class="form-control" placeholder="School name" required>
				</div>
                
				<div class="form-group">

					<label><b>University Name</b></label>
					<input type="text" name="varsity" class="form-control" placeholder="University Name" required>
				</div>
				
				<div class="form-group">
					<label><b>Skill</b></label> <br> 
					<select name="skills" required>
						    <option value="Programmer"> Programmer</option>
                            <option value="Microsoft office">Microsoft office</option>
                            <option value="Computer oparater">Computer oparater</option>
                            <option value="Typing">Typing</option>
                          </select>
				</div>
				
                <div class="form-group">

					<label><b>Religion</b></label> <br> 

					<select name="religion" required>
						    <option value="Islam">Select Religion</option>
                            <option value="Islam">Islam</option>
                            <option value="Hindu">Hindu</option>
                            <option value="Christian">Christian</option>
                            
                          </select>
				</div>

				<div class="form-group">

					<label><b>Gender</b></label> <br>
					<input type="radio" name="gender" value="Male" required>Male &nbsp;
                    <input type="radio" name="gender" value="Female" required>Female
				</div>



				<button type="submit" class="btn btn-primary"> Create </button>

			</form>
		</div>
	</body>
</html>