<?php
session_start();
 if(!isset($_SESSION['username'])){
    header('location:main.php');
//header('location:main.php');
$con=mysqli_connect('localhost','root','');
mysqli_select_db($con,'myproject');
$name = $_POST['user'];
$phone=$_POST['number'];
$email = $_POST['email'];


$s = " select * from user1 where name='$name'";

$result = mysqli_query($con, $s); 

$num = mysqli_num_rows($result);

if($num == 1){
	echo "username already taken";
}
else{
	$reg = " insert into user1 (name, email,phone) values('$name', '$email', '$phone' )";

	mysqli_query($con, $reg);
	echo "User add Successfully";
	$_SESSION['msg'] = '<div class="message">user add Successfully</div>';
	header('location: user.php');
}


?>